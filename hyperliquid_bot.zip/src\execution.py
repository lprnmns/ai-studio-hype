from __future__ import annotations

import asyncio
import json
import math
import threading
import time
from typing import Any, Dict, List, Optional

import aiohttp
from hyperliquid.utils.signing import sign_l1_action

from src.connector import HyperliquidConnector


class ExecutionManager:
    """Low-latency Hyperliquid executor using raw aiohttp requests."""

    def __init__(self, connector: HyperliquidConnector, symbol: str = "HYPE") -> None:
        self.connector = connector
        self.symbol = symbol.upper()
        self.info = connector.info
        self.wallet = connector.agent_account
        self.master_address = connector.master_address
        self.base_url = getattr(connector.exchange, "base_url", "https://api.hyperliquid.xyz") or "https://api.hyperliquid.xyz"
        self.is_mainnet = "api.hyperliquid.xyz" in self.base_url

        self.last_responses: Dict[str, Any] = {}

        self._loop = asyncio.new_event_loop()
        self._session: Optional[aiohttp.ClientSession] = None
        self._thread = threading.Thread(target=self._loop.run_forever, daemon=True)
        self._thread.start()
        self._submit(self._ensure_session())

    # ------------------------------------------------------------------
    # Public sync wrappers
    # ------------------------------------------------------------------
    def setup_account(self) -> Dict[str, Any]:
        print("🛠️ Setting HYPE leverage to 3x")
        response = self.connector.exchange.update_leverage(leverage=3, name=self.symbol)
        print(f"✅ Leverage response: {response}")
        return response

    def execute_entry_ioc(self, size: float, spot_price: float, perp_price: float, spot_asset_id: str) -> bool:
        return self.execute_entry_parallel(size, spot_price, perp_price, spot_asset_id)

    def execute_exit_alo_or_ioc(
        self,
        size: float,
        spot_price: float,
        perp_price: float,
        spot_asset_id: str,
        symbol: str = "HYPE",
    ) -> bool:
        return self.execute_exit_parallel(size, spot_price, perp_price, spot_asset_id, symbol)

    def execute_entry_parallel(
        self,
        size: float,
        spot_price: float,
        perp_price: float,
        spot_asset_id: str,
    ) -> bool:
        return self._submit(self._execute_entry_parallel(size, spot_price, perp_price, spot_asset_id))

    def execute_exit_parallel(
        self,
        size: float,
        spot_price: float,
        perp_price: float,
        spot_asset_id: str,
        symbol: str = "HYPE",
    ) -> bool:
        return self._submit(self._execute_exit_parallel(size, spot_price, perp_price, spot_asset_id, symbol))

    # ------------------------------------------------------------------
    # Core async logic
    # ------------------------------------------------------------------
    async def _execute_entry_parallel(
        self,
        size: float,
        spot_price: float,
        perp_price: float,
        spot_asset_id: str,
    ) -> bool:
        request_size = self._round_size_down(size)
        if request_size <= 0:
            raise ValueError("Order size must be positive.")

        spot_action = self._build_order(
            asset_id=self._spot_asset_to_int(spot_asset_id),
            is_buy=True,
            size=request_size,
            price=self._round_to_sig_figs(spot_price * 1.05),
            reduce_only=False,
        )
        perp_action = self._build_order(
            asset_id=self._perp_asset_id(self.symbol),
            is_buy=False,
            size=request_size,
            price=self._round_to_sig_figs(perp_price * 0.95),
            reduce_only=False,
        )

        print("🚀 Firing parallel ENTRY orders...")
        signed_payloads = [
            self._sign_payload(spot_action, nonce_suffix=0, label="spot"),
            self._sign_payload(perp_action, nonce_suffix=1, label="perp"),
        ]
        try:
            spot_resp, perp_resp = await self._post_parallel(signed_payloads)
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            print(f"⚠️ Network error during entry: {exc}")
            return False
        spot_fill = self._extract_filled_size(spot_resp)
        perp_fill = self._extract_filled_size(perp_resp)
        spot_ok = self._is_success(spot_resp)
        perp_ok = self._is_success(perp_resp)

        if spot_ok and perp_ok and self._fills_match(spot_fill, perp_fill, request_size):
            return True

        if not spot_ok and not perp_ok:
            print("❌ Entry failed on both legs.")
            return False

        print("⚠️ Mismatch detected! Closing all positions...")
        if spot_fill > 0:
            await self._panic_close_spot(self._spot_asset_to_int(spot_asset_id), spot_fill, spot_price)
        if perp_fill > 0:
            await self._panic_close_perp(perp_fill, perp_price)
        return False

    async def _execute_exit_parallel(
        self,
        size: float,
        spot_price: float,
        perp_price: float,
        spot_asset_id: str,
        symbol: str,
    ) -> bool:
        spot_balance = self._floor_size(self._get_spot_balance(symbol=symbol, asset_id=spot_asset_id))
        if spot_balance <= 0:
            print("⚠️ No spot balance detected; skipping exit.")
            return False

        perp_size = self._round_size_down(size)
        if perp_size <= 0:
            raise ValueError("Perp size must be positive.")

        spot_action = self._build_order(
            asset_id=self._spot_asset_to_int(spot_asset_id),
            is_buy=False,
            size=spot_balance,
            price=self._round_to_sig_figs(spot_price * 1.001),
            reduce_only=False,
        )
        perp_action = self._build_order(
            asset_id=self._perp_asset_id(symbol),
            is_buy=True,
            size=perp_size,
            price=self._round_to_sig_figs(perp_price * 0.999),
            reduce_only=True,
        )

        print("🚀 Firing parallel EXIT orders...")
        signed_payloads = [
            self._sign_payload(spot_action, nonce_suffix=2, label="spot"),
            self._sign_payload(perp_action, nonce_suffix=3, label="perp"),
        ]
        try:
            spot_resp, perp_resp = await self._post_parallel(signed_payloads)
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            print(f"⚠️ Network error during exit: {exc}")
            return False
        spot_ok = self._is_success(spot_resp)
        perp_ok = self._is_success(perp_resp)

        if spot_ok and perp_ok:
            return True

        if not spot_ok and not perp_ok:
            print("❌ Exit failed on both legs.")
            return False

        print("⚠️ Exit encountered partial failure; please retry.")
        return False

    # ------------------------------------------------------------------
    # Networking / signing
    # ------------------------------------------------------------------
    async def _ensure_session(self) -> None:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=5)
            self._session = aiohttp.ClientSession(timeout=timeout)

    async def _reset_session(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
        self._session = None
        print("⚠️ Connection reset. Re-establishing tunnel...")
        await self._ensure_session()

    async def _post_parallel(self, signed_payloads: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        await self._ensure_session()
        coros = [self._post_signed(item["payload"]) for item in signed_payloads]
        try:
            results = await asyncio.gather(*coros)
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            await self._reset_session()
            raise exc
        leg_map: Dict[str, Any] = {}
        for idx, (item, resp) in enumerate(zip(signed_payloads, results)):
            leg = item.get("label") or f"leg{idx}"
            print(f"📬 {leg.upper()} response: {resp}")
            leg_map[leg] = resp
        self.last_responses = leg_map
        return results

    async def _post_signed(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        assert self._session is not None
        url = f"{self.base_url.rstrip('/')}/exchange"
        async with self._session.post(url, json=payload, headers={"Content-Type": "application/json"}) as resp:
            text = await resp.text()
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"status": "err", "error": text}

    async def _panic_close_spot(self, asset_int: int, size: float, spot_price: float) -> None:
        size = self._round_size_down(size)
        if size <= 0:
            return
        action = self._build_order(
            asset_id=asset_int,
            is_buy=False,
            size=size,
            price=self._round_to_sig_figs(spot_price * 0.98),
            reduce_only=False,
        )
        signed = self._sign_payload(action, nonce_suffix=5, label="spot_panic")
        try:
            resp = (await self._post_parallel([signed]))[0]
            print(f"🆘 Emergency SPOT close response: {resp}")
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            print(f"🆘 Emergency SPOT close failed: {exc}")

    async def _panic_close_perp(self, size: float, perp_price: float) -> None:
        size = self._round_size_down(size)
        if size <= 0:
            return
        action = self._build_order(
            asset_id=self._perp_asset_id(self.symbol),
            is_buy=True,
            size=size,
            price=self._round_to_sig_figs(perp_price * 1.02),
            reduce_only=True,
        )
        signed = self._sign_payload(action, nonce_suffix=6, label="perp_panic")
        try:
            resp = (await self._post_parallel([signed]))[0]
            print(f"🆘 Emergency PERP close response: {resp}")
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            print(f"🆘 Emergency PERP close failed: {exc}")

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------
    def _build_order(
        self,
        asset_id: int,
        is_buy: bool,
        size: float,
        price: float,
        reduce_only: bool,
    ) -> Dict[str, Any]:
        return {
            "type": "order",
            "grouping": "na",
            "orders": [
                {
                    "a": asset_id,
                    "b": is_buy,
                    "p": f"{price:.8f}",
                    "s": f"{size:.4f}",
                    "r": reduce_only,
                    "t": {"limit": {"tif": "Ioc"}},
                }
            ],
        }

    def _sign_payload(self, action: Dict[str, Any], nonce_suffix: int, label: str = "") -> Dict[str, Any]:
        nonce = int(time.time() * 1000) + nonce_suffix
        signature = sign_l1_action(self.wallet, action, None, nonce, None, self.is_mainnet)
        payload = {"action": action, "signature": signature, "nonce": nonce, "vaultAddress": None}
        return {"payload": payload, "nonce": nonce, "label": label}

    def _perp_asset_id(self, symbol: str) -> int:
        meta = self.info.meta()
        for idx, asset in enumerate(meta.get("universe", [])):
            if asset.get("name", "").upper() == symbol.upper():
                return idx
        raise ValueError(f"Perp symbol '{symbol}' not found in meta().")

    def _spot_asset_to_int(self, spot_asset_id: str) -> int:
        if spot_asset_id.startswith("@"):
            return int(spot_asset_id[1:])
        if spot_asset_id.isdigit():
            return int(spot_asset_id)
        raise ValueError(f"Unexpected spot asset id format: {spot_asset_id}")

    def _extract_filled_size(self, response: Any) -> float:
        statuses = self._extract_statuses(response)
        if not statuses:
            return 0.0
        for status in statuses:
            if self._status_has_error(status):
                return 0.0
            filled = status.get("filled")
            if filled and filled.get("totalSz"):
                try:
                    return float(filled["totalSz"])
                except (TypeError, ValueError):
                    continue
        return 0.0

    def _extract_statuses(self, response: Any) -> List[Dict[str, Any]]:
        if not isinstance(response, dict):
            return []
        payload = response.get("response") or response
        data = payload.get("data", payload) if isinstance(payload, dict) else {}
        statuses = data.get("statuses")
        return statuses if isinstance(statuses, list) else []

    @staticmethod
    def _status_has_error(status: Dict[str, Any]) -> bool:
        if not isinstance(status, dict):
            return True
        state = str(status.get("status", "")).lower()
        if state in {"error", "rejected"}:
            return True
        return "error" in status

    @staticmethod
    def _round_size_down(value: float) -> float:
        return math.floor(value * 100) / 100 if value > 0 else 0.0

    @staticmethod
    def _floor_size(value: float) -> float:
        return math.floor(value * 100) / 100 if value > 0 else 0.0

    @staticmethod
    def _round_to_sig_figs(value: float, sig_figs: int = 5) -> float:
        if value == 0:
            return 0.0
        return float(f"{value:.{sig_figs}g}")

    @staticmethod
    def _is_success(response: Any) -> bool:
        return isinstance(response, dict) and response.get("status") == "ok"

    def _get_spot_balance(self, symbol: str, asset_id: Optional[str] = None) -> float:
        state = self.info.spot_user_state(self.master_address)
        balances = state.get("balances", [])
        symbol_upper = symbol.upper()
        for balance in balances:
            coin_key = balance.get("coin")
            if not coin_key:
                continue
            try:
                amount = float(balance.get("total", 0.0))
            except (TypeError, ValueError):
                amount = 0.0
            if coin_key.upper() == symbol_upper:
                return amount
            if asset_id and coin_key == asset_id:
                return amount
        return 0.0

    @staticmethod
    def _fills_match(spot_filled: float, perp_filled: float, target: float, tolerance: float = 0.02) -> bool:
        min_fill = target * (1 - tolerance)
        return spot_filled >= min_fill and perp_filled >= min_fill

    def _submit(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self._loop).result()
